package com.example.piedrapapeltijera.domain.valueObjects

enum class GameResult {
    GANAR, PERDER, EMPATE
}