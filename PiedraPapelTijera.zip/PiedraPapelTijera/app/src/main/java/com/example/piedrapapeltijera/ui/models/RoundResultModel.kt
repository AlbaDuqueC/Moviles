package com.example.piedrapapeltijera.ui.models

data class RoundResultModel(
    val playerChoice: String,
    val aiChoice: String,
    val result: String,
    val resultColor: Int
)