package com.example.prueba2

import android.os.Bundle
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.prueba2.databinding.ActivityMainBinding
import com.example.prueba2.databinding.ActivityWelcomeBinding

class WelcomeActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_welcome)

        val binding = ActivityWelcomeBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.btnMiBoton2.text = "PÚLSAME YA"

        binding.btnMiBoton2.setOnClickListener {
            val toast = Toast.makeText(
                applicationContext,
                "Bienvenido" + binding.inpTexto.text,
                Toast.LENGTH_SHORT
            ).show()
        }

    }
}