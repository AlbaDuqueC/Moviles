package com.example.pruebadecosa

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.pruebadecosa.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        /*setContentView(R.layout.activity_main)

        val boton = findViewById<Button>(R.id.btnACCEDER)

        boton.text = "ACCEDER"*/

        val binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.btnACCEDER.text = "ACCEDER"

        binding.btnACCEDER.setOnClickListener {
            // Obtener los valores **en el momento del clic**
            val inpUsuario = binding.inputUsuario.text.toString()
            val inpContraseña = binding.inputPassword.text.toString()

            if (inpUsuario == "usuario" && inpContraseña == "usuario") {
                // Abrir la otra pantalla
                val intent = Intent(this, MainMenuActivity::class.java)
                Toast.makeText(
                    this,
                    "INICIANDO SESIÓN",
                    Toast.LENGTH_SHORT
                ).show()
                intent.putExtra("USUARIO_KEY", inpUsuario)
                startActivity(intent)
            } else {
                Log.d(":::tag","Hola")
                    Toast.makeText(
                        this,
                        "ERROR AL INICIAR SESION",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }

    }
}